from datetime import datetime
import pickle
nbr_evenement=0
def check_date(debut,fin):
 try:
    date_split=debut.split('-')
    date_split_2=fin.split('-')
    for x in [date_split,date_split_2]:
        if len(x)==3 and len(x[0])==4 and 1<=int(x[1])<=12 or 1<=int(x[3])<=32:
            pass 
        else:
            return False
        
    debut=datetime.strptime(debut,"%Y-%m-%d")
    fin=datetime.strptime(fin,"%Y-%m-%d")
    return debut<=fin

 except: return False

def est_international(x):
    if x.upper()=="OUI":return True
    else: return False


#2
def info(tableauT):
    global nbr_evenement
    #check
    while True:
     n=input("ُEnter the number of 'evenement' you want to input :" ).strip()
     if n.isdigit():
        n=int(n) 
        break
     else: print("please entre a number .. !\n")
    #loop
    for _ in range(n):
      nbr_evenement+=1
      #titre:
      while True:
        titre=input(f"entrez le titre de l'venement {nbr_evenement}: ").strip()
        if titre and not any (titre.lower()==entry['titre'].lower for entry in tableauT):
           break
        else: print("cette titre est deja utilise..\n")
      #ville:
      ville=input("entrez le nom de la ville : ").strip().capitalize()
      #date:
      while True:
        date_debut=input("entrez la date de debut (year-month-days): ").strip()
        date_fin=input("entrez la date de fin evenement (year-month-days) : ").strip()
        if check_date(date_debut,date_fin):
            break
        else:
            print("please write in the required format 'y-m-d' and 'date debut'<='date fin'.\n")
        
      #categorie:
      while True:
        categorie=input('choice one of this categories ("Musique" or "Theatre" or "Exposition") : ').strip().capitalize()
        if categorie in ['Musique' ,'Theatre' ,'Exposition']: break
        else: print('please write carefully!!\n')
      #international:
      international=input("est ce que cete evenement est international (oui or non) : ").strip()

      #save in tabeleau:
      event={
            'titre':titre,
            'ville':ville,
            'date_debut':date_debut,
            'date_fin':date_fin,
            'categorie':categorie,
            'international':est_international(international)
           }  

      tableauT.append(event)
    return nbr_evenement

#4
def nbr_d_categorie(tableauT,categorie):
    somme_event=sum(1 for x in tableauT if x['categorie']==categorie)
    if somme_event>0:
     print(f"le nombre d'evenement d'apres le categorie {categorie} est : {somme_event}")
    else: print('aucun evenement..\n')
    

#5:Afficher les trois événements les plus récents
def trois_evenet_recents(tableauT):
        plus_recent=sorted(tableauT,key=lambda x : x['date_debut'] ,reverse=False)[:3]
        plus_recent=[x['titre'] for x in tableauT]
        print(f"les trois evenement recents est : {' , '.join(plus_recent)}")

#6:Supprimer un événement par son titre
def sup_evenement_titre(tableauT,titre_input):
   if any (x['titre']==titre_input for x in tableauT):
     for x in tableauT:
        if x['titre']==titre_input:
           tableauT.remove(x)     
   else:
      print("there is no event with this title : %s \n"%titre_input)

#7:Nombre total de jours d’événements pour une ville
def nbr_j_event(tableauT,ville_input):
   nbr_jours=0
   for x in tableauT:
      if x['ville']==ville_input:
         nbr_jours+=(x['date_fin']-x['date_debut']).days
   if nbr_jours==0:
      print("the city you entered does not exist..\n")
#8:Afficher les événements dans un intervalle de dates 
def event_intervalle(tableauT,date1,date2):
   if check_date(date1,date2):
      event_dans_inter=[x for x in tableauT if date1<=x['date_debut']<=date2]
      if event_dans_inter:
         print("les evenement dans un intervalle entre {} and {} est : {}".format(date1,date2,' - '.join(event_dans_inter)))
      else: print('aucun evenement..\n')
   else: 
      print('there is an error in the date , please try again\n')
   
#9:Enregistrer les événements d'une catégorie dans un fichier
def save_as_binary(tableauT,categorie_input,filename):
   tableau=[(x) for x in tableauT if x['categorie']==categorie_input]
   with open (filename,'wb') as file:
      pickle.dump(tableau,file)
def save_as_text(tableauT,categorie_input,filename):
   tableau=[str(x) for x in tableauT if x['categorie']==categorie_input]
   with open (filename,'w') as file:
      file.write('\n'.join(tableau))


#10:Catégorie avec l'événement le plus ancien
def plus_ancien(tableauT,categorie_inp):
   plus_ancien=None
   tableau=[x for x in tableauT if x['categorie']==categorie_inp]
   if tableau :
      for x in tableau:
         if plus_ancien is not None: 
            if x['date_start']<plus_ancien:
               plus_ancien=x['date_start']
         else:
            plus_ancien=x['date_start']
         
#11:show menu
def menu(x):
 if x==1:
   print("""  
    _____choix:
    1---->out ,
    2---->add evenement ,
    3---->show all evenements , 
    4---->show nombre des enement d'apres le categorie,
    5---->affichage les trois evenements les plus recents ,
    6---->Supprimer un événement par son titre,
    7---->Nombre total de jours d’événements pour une ville,
    8---->Afficher les événements dans un intervalle de dates,
    9---->Enregistrer les événements d'une catégorie dans un fichier,
    10--->Catégorie avec l'événement le plus ancien
    11--->show menu
    12--->hide menu
    """)
   