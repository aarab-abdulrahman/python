from fonctionsevent import menu,plus_ancien,save_as_text,save_as_binary,event_intervalle,nbr_j_event,sup_evenement_titre,trois_evenet_recents,nbr_d_categorie,info
tableauT=[]
x=1
#-------------------------------------------------------------------
#choix:
while True:
    if not tableauT:
     info(tableauT)
    else:
        #choice:
        menu(x)
        x=input("type your choice here : ").strip()
        if x=='1': break
        elif x=='2': info(tableauT)
        elif x=='3': print('\n'.join(str(x) for x in tableauT))
        elif x=='4':
            cat=input("entre le nom de cataegorie : ").strip().capitalize()
            nbr_d_categorie(tableauT,cat)
        elif x=='5': 
            if len(tableauT)<3:
                print("le nombre des evenement est petit...")
            else:
                trois_evenet_recents(tableauT)
        elif x=='6':
           titre_input=input('entrez le titre : ').strip()
           sup_evenement_titre(tableauT,titre_input) 
        elif x=='11':
           if x==1:
              print("the menu is on display of course..\n")
           else:
              x=1
        elif x=='12':
           if x==0:
              print("the menu is not display of course...\n")
           else:
              x=0
        elif x=="7":
           ville_input=input("entrez le nom de ville : ").strip().capitalize()
           nbr_j_event(tableauT,ville_input)
        elif x=='8':
           date1=input("entrez date debut : ").strip()
           date2=input("entre fin date : ").strip()
           event_intervalle(date1,date2)
        elif x=='9':
           categorie_input=input("entrez name de categorie : ").strip().capitalize()
           filename=input("entre your file name : ").strip()
           ask=input("Do you want to save in to binary(1) or to text(2)").strip()
           if ask=='1': save_as_binary(tableauT,categorie_input,filename)
           else: save_as_text(tableauT,categorie_input,filename)
        elif x=='10':
           categorie_int=input("entrez le nom de categorie : ").strip().capitalize
           plus_ancien(tableauT,categorie_int)
              