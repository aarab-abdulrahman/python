import pickle
from datetime import datetime

# Classe représentant une circonscription
class Circonscription:
    def __init__(self, nom, population, date_creation, region, est_principale):
        self.nom = nom
        self.population = population
        self.date_creation = datetime.strptime(date_creation, "%Y-%m-%d")
        self.region = region
        self.est_principale = est_principale

# Liste pour stocker les circonscriptions
circonscriptions = []

# 1. Remplir un tableau T par n circonscriptions
def remplir_circonscriptions(n):
    for _ in range(n):
        nom = input("Nom de la circonscription: ")
        population = int(input("Population: "))
        date_creation = input("Date de création (YYYY-MM-DD): ")
        region = input("Région (Casablanca-Settat, Marrakech-Safi, Drâa-Tafilalet): ")
        est_principale = input("Est-elle principale ? (oui/non): ").strip().lower() == "oui"
        
        if region not in ["Casablanca-Settat", "Marrakech-Safi", "Drâa-Tafilalet"]:
            print("Région invalide, veuillez réessayer.")
            continue
        
        circonscriptions.append(Circonscription(nom, population, date_creation, region, est_principale))
