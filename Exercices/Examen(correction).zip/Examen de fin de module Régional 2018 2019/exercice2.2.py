nbr_parfait=[]
a=sum(nbr_parfait)

def est_parfait(n,a):
    for x in range(1,n):
        if n%x==0:
            nbr_parfait.append(x)
    if a==n :
        return 1
    else:
        return 0
    
def if_est_negatif(a):
    if a>=0: return 0
    else: return 1

try:
    n=int(input("type a number : ").strip())
    if est_parfait(n,a) and not if_est_negatif(a):
        print(f"le nombre {n} est parfait et positive.")
    elif est_parfait(n,a) and if_est_negatif(a):
        print(f"le nombre {n} est parfait et negatif.")
    elif not est_parfait(n,a) and if_est_negatif(a):
        print(f"le nombre {n} n'est pas parfait et negatif." ) 
    elif not est_parfait(n,a) and not if_est_negatif(a):
        print(f"le nombre {n} n'est pas parfait et positive.")
except:
    print("error")