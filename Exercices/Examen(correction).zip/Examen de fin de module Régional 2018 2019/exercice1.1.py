
def est_palindrome(n):
    if str(n)==(str(n)[::-1]):
        return True
    else:
        return False
    

try:

    n=input("type .... : ")
    if est_palindrome(n):
        print(f'{n} est palindrome')
    else:
        print(f"{n} n'est pas palidrome")
except:
    print("error")