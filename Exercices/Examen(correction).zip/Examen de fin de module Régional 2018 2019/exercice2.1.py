nbr_parfait=[]
def est_parfait(n):
    for x in range(1,n):
        if n%x==0:
            nbr_parfait.append(x)
    
    if sum(nbr_parfait)==n:
        return 1
    else:
        return 0
    
try:
    n=int(input("type a number : ").strip())
    if est_parfait(n):
        print(f"le nombre {n} est parfait.")
    else:
        print(f"le nombre {n} n'est pas parfait." ) 

except:
    print("error")