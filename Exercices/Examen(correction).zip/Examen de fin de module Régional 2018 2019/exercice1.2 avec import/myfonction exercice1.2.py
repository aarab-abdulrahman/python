#myfonction

def est_palindrome(n):
    n=str(n)
    # if n==(n)[::-1]:
    #     return True
    # else:
    #     return False
    return n==n[::-1]
    