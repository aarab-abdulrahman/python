#exercie1.2
from myfonction import est_palindrome


while True:
  x=input("\ntype : ")
  if est_palindrome(x):
    print('--')
    break
