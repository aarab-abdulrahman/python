from myfonction import est_palindrome
# def est_plindrome(n):
#   if n == n[::-1]:
#     return 1
#   else:
#     return 0
  
while True:
  n=input("\ntype : ")
  if est_plindrome(n):
    break
