#comment declarer une date

import datetime
now=datetime.datetime.now()
print(now.strftime("%Y-%m-%d %H horses %M Months %S seconds"))

#COmment calculer la difference entre deux dates 
a=input("type date ('Year','Month','days') : ").split(",")
x=datetime.datetime.now().strftime("%Y,%m,%d").split(',')
list_date=''
for o in range(3):
    date=int(x[o])-int(a[o])
    # print(date)
    list_date+=str(date,' ')


print(list_date)