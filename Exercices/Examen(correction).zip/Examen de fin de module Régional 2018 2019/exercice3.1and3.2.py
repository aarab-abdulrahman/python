#exercice3.1


import string 
import random

def alphabetiques():
 new=list(string.ascii_uppercase)[:26]
 random.shuffle(new)
 alpha=''.join(new)
 return alpha

print(alphabetiques())

#3.2


def Crypter(message):
    alphabet_random = alphabetiques()
    correspondance = {original: random for original, random in zip(string.ascii_uppercase, alphabet_random)}

    message_crypte = ''
    for char in message:
        if char.upper() in correspondance:
            if char.isupper():
                message_crypte += correspondance[char]
            else:
                message_crypte += correspondance[char.upper()].lower()
        else:
            message_crypte += char  

    return message_crypte


message = input("type : ")
message_crypte = Crypter(message)
print("Message original:", message)
print("Message crypté:", message_crypte)

